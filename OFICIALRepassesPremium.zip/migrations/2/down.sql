
DROP INDEX idx_users_email;
DROP TABLE users;
