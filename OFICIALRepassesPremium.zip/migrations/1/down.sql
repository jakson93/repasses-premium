
DROP INDEX idx_motorcycle_images_motorcycle_id;
DROP INDEX idx_motorcycles_is_featured;
DROP INDEX idx_motorcycles_price;
DROP INDEX idx_motorcycles_year;
DROP INDEX idx_motorcycles_brand;
DROP TABLE motorcycle_images;
DROP TABLE motorcycles;
